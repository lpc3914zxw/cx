<?php
/**
 * Created by PhpStorm.
 * User: lupengcheng
 * Date: 2020-09-17
 * Time: 13:57
 */
return[

            'appId'             => '2021001163647643',
            'gatewayUrl'        => 'https://openapi.alipay.com/gateway.do',
            'rsaPublicKey'      => '',
            'rsaPrivateKey'     => 'MIIEogIBAAKCAQEAisEWrsiMrsk5Jt9txQ88fFD/8eRaXwO07+FFu89aFE01irKNAWT7rpLsiexC3VZGsyj7pBQ9QNTI8+xhylRQQwNdxNJpr3c7fFhjw6jqIoA05g8lsjyIdtXMI409hpc/Z58hZccppYxvjp3J+8DgjqgMbFTLH+WZm8fm8ry8uIfZD8OjY4pKs9d8uY8XtAE9qPNGhMk3D7ixK4dYSqRJZKucWT9rtD/4yQ+n/DiNC/rXfkVmc/hx369XOGNGZDqYbkl77uSTD9YSwQmUacwp9ZKiCIUoCJgjW0jUFilc60Bt3kKxkySy0gwAT4JkizVrBZrpsc2MwVplxTHfDzWb5QIDAQABAoIBACV0iAX4dxl7kiTvLTeDrGU2jFCkvsxlOMOEQQm4qG1QhkKBflTBCLuQR6/Xihkrf/w+9ObO29YTWoeV6LPwXJYqY3aNAiBuhC1FwvB/OWzExQLRVfCuLHw/rFJwfwpE68WyDBboU1Kv/TE3YN3HrBZ2QJxBq29Z0ERgCvS9hAgfpejfMwzAfmAQaHIKRacTDqJlBfkyGl7d2BtT4h1/r5CzlmZ31qkHvq38kxahg6zQLWJpFVCOrAoyIL2cDWeANPoa44Bl7OBraH+zoKhmXnsYRuEPxuJaQ9GRo9ErTxYxZOJklyrfuscr8X7c6YT9A7tukBbXiJP8T6FUW7RcbgUCgYEAwkRbfyCfrVNTFtBwlRMicSCTHdND3E0GTXvyN6npwmsX5GNE0XDS0Am3v0k8iAmz5Yr69E+Y06hdNoApTCNxDIP5uFCOa7q6qxvLKZaxeNdTChM1TltMgEqB3FnpXijPsauoDwTuJ1RtM4mYhz4+3IIE7O2W7xahF5moHbNLE/sCgYEAttjC+ZaT61noQKgfBWxna6F8tEYlz6tS2sqKnYhoB3umvvpyZzLLNUEC1cTCmH0mQMrWr0zZGtbQUArbVuLVyCM2SXtxEKbnyg8Ft1SaAZjckkfmmy0n5FwEk/31lVzVyFALf3FrAYdzLP28P1rnswvAEyz1Ds4mSg0XkSlTKZ8CgYAyB8TAkrhMvP7TC09TNSBTnh4FOllprPSIk/knWLz48veuO9qHTdUc+sO1objTGByaaxaCQNWM/Pk0hgEcuKvumzZ+v1BOckKMupWx2jtOcbXTDGtYCK9FAus6wnUVaNFEYn7fj1d+DYIqGa+MdP1fcKSwF+gdHujR2SKws3IMbQKBgFChXbl6cVhDmWuJt8RIfYK0/6zvkhT109+vmVjGojlKicmF35UqjPm65WknDzj3VzsTN4CuPr7bI5locDjsZqGPBY155e4V6/jqjva9U/yIUBwhoMulKgZFna81OmrXOV7QDYHxneJavKuGaND3YV1PPTA3jwksVy4of8//jTC5AoGAZvYq9iH1EEqWPprZHWNPTgfKoOHR1KB2HW9j2zHiwBVZXyVHxQ3zlz9y1Kh4B2/cKdO2neL7Cv2N3VIHn8b5GWiG3eq1sTq4bFxlAMscV3sefABKiNKMpwNxyyTPTgi5+MSvxD9Jc5jU+5GeMsk3V4RU1yS1gccGZ7AYdtf/nBw=',
            'alipayrsaPublicKey'=> 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAgbPyffwy3iPQz0dodFKZZXRF5b6PMlAOhOrzuMixuSlN8qe3bLpE1CHMaVvgQZcYOzJzqd0d0mi69IPR8A1tZkCqF/jX/zbNpKDc4n3mPy7mA9gjfv2qJVpsysnaVSTcnKUkq8BD+MHGKq28LTF7GDts67glr7fni0LgV5NueLy3+BW6BFhG4cCNCD+Zq0hSQffrQnnk8wDha9kfrhsKZvyCN8wCCeOEGciQY3+9CR7u3jI4murUXdZtf2b1NV0qFCbivkDZoHEurRmDnkcMVrVTWVXMfxxfbxsruHRtHTAEb37tzp0DnJKfPRqaVuTN64is64/ywBWrUaanjmX89QIDAQAB',
            'format'            => 'json',
            'charset'           => 'UTF-8',
            'signType'          => 'RSA2',
            'transport'         => 'http',

];
