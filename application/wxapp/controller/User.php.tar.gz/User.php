<?php
namespace app\wxapp\controller;
use think\Controller;
use app\wxapp\controller\Base;
use app\wxapp\model\Level;
use think\Request;
use think\Cache;

class User extends Base{
    
   
    public function myInfo() {
        $this->uid = 5;
         $user = new \app\wxapp\model\User;
        $userInfo = $user->where('id',$this->uid)->field('id,name,headimg,student_no,level,signature,score,wechat')->find();
        
        if(empty($this->uid)) {
            return returnjson(1100,'该用户已在其他设备登陆');
        }
       
        if($userInfo){//is_auth 0未认证 1已提交审核 2已认证 3认证驳回
            $level = new level();
            $mylevel = $level->where('value',$userInfo)->field('name')->find();
            if(empty($userInfo['signature'])){
                $userInfo['signature'] = '';
            }
            $userInfo['levelname'] = $mylevel['name'];
           
            
            return returnjson(1000,$userInfo,'获取成功');
        }
        return returnjson(1001,'','获取失败');
    }
    /*
    * 发送短信
    */
    public function sendcode() {
        $this->uid = 5;
        $post = Request::instance()->post();
        $tel = $post['tel'];
        if(empty($this->uid)) {
            return returnjson(1100,'','该用户已在其他设备登陆');
        }
        if(empty($post['type'])){
            return returnjson(1001,'','参数缺失');
        }
        $user_model = new \app\wxapp\model\User;
        if (!preg_match("/^1[3456789]\d{9}$/", $tel)) {
            return returnjson(1001, '', '手机号码有误!');
        }
        
        $myuserinfo = $user_model->where(['id' => $this->uid])->find();
        $str = '1234567890';
        $randStr = str_shuffle($str); //打乱字符串
        $code = substr($randStr, 0, 4); //substr(string,start,length);返回字符串的一部分\
        vendor('aliyun-dysms-php-sdk.api_demo.SmsDemo');
        $content = ['code' => $code];
        switch ($post['type']) {
           case "up_password":
             //$teltype = 
             break;
           case "set_pay_password":
             
             break;
           case "up_tel":
             
             break;
           case "new_tel":
              if($tel == $myuserinfo['tel']){
                  return returnjson(1001, '', '更改的手机号不能相同!');
              } 
              $userinfo = $user_model->where(['tel' => $tel])->find();
             // $oldtelcode = cache('up_tel'.$userinfo['tel']);
              //if(empty($oldtelcode)){
              //    return returnjson(1, '', '验证码错误!');
             // }
             if ($userinfo) {
                return returnjson(1001, '', '此手机号已被注册!');
             }
           break;
           default:
             return returnjson(1001, '', '验证码类型错误!');
        }
        //echo $post['type'].$tel;exit;
        $response = \SmsDemo::sendSms($tel, $content);
        $response = object_to_array($response);
        if ($response['Message'] == 'OK') {
            //cache($post['type'].$tel,$code,1800);
            Cache::set($post['type'].$tel,$code,1800);
            return returnjson(1000, '', '发送成功');
        } else {
            return returnjson(1001, '', $response['Message']);
        }
    }
    //修改手机时验证老号码验证码
    public function checkTelCode(){
        $this->uid = 5;
        $post = Request::instance()->post();
        if(empty($this->uid)) {
            return returnjson(1100,'该用户已在其他设备登陆');
        }
        if(empty($post['tel'])||empty($post['code'])){
            return returnjson(1001,'','参数缺失');
        }
        //$code = $post['code'];
        $user = new \app\wxapp\model\User;
        $userInfo = $user->where('id',$this->uid)->field('id,name,headimg,student_no,level,signature,score,wechat,tel')->find();
        if (!Cache::has('up_tel'.$userInfo['tel'])){
                return returnjson(1001,'','验证码错误');
            }
            
            if (Cache::get('up_tel'.$userInfo['tel']) != $post['code']) {
                 return returnjson(1001,'','验证码错误');
            }
            return returnjson(1000,'','验证通过');
        
    }
    public function updateInfo() {
        $this->uid = 5;
        $post = Request::instance()->post();
        if(empty($this->uid)) {
            return returnjson(1100,'该用户已在其他设备登陆');
        }
        if(empty($post['type'])||empty($post['param'])){
            return returnjson(1001,'','参数缺失');
        }
        $param = $post['param'];
        $user = new \app\wxapp\model\User;
        $userInfo = $user->where('id',$this->uid)->field('id,name,headimg,student_no,level,signature,score,wechat,tel,salt')->find();
        if($post['type'] == 1){
            $key = 'headimg';
        }elseif($post['type'] == 2){
            $key = 'name';
        }elseif($post['type'] == 3){
            $key = 'signature';
        }elseif($post['type'] == 4){
            
            if (!Cache::has('up_password'.$userInfo['tel'])){
                return returnjson(1001,'','验证码错误');
            }
            
            if (Cache::get('up_password'.$userInfo['tel']) != $post['code']) {
                 return returnjson(1001,'','验证码错误');
            }

            
            $key = 'password';
            $param = splice_password($param,$userInfo['salt']);
        }elseif($post['type'] == 5){
            if (!Cache::has('new_tel'.$param)){
                return returnjson(1001,'','验证码错误');
            }
            
            if (Cache::get('new_tel'.$param) != $post['code']) {
                 return returnjson(1001,'','验证码错误');
            }
            $key = 'tel';
        }elseif($post['type'] == 6){
            if (!Cache::has('set_pay_password'.$userInfo['tel'])){
                return returnjson(1001,'','验证码错误');
            }
            
            if (Cache::get('set_pay_password'.$userInfo['tel']) != $post['code']) {
                 return returnjson(1001,'','验证码错误');
            }
            
            $key = 'pay_password';
            
            $param = splice_password($param,$userInfo['salt']);
        }elseif($post['type'] == 7){
            $key = 'wechat';
        }else{
            return returnjson(1001,'','修改类型非法');
        }
        
        $res = $user->where('id',$this->uid)->setField($key,$param);
       
        if($res){
            
            return returnjson(1000,'','修改成功');
        }
        return returnjson(1001,'','修改失败');
    }

    //退出登录
    public function outlogin(){
        $this->uid = 5;
        $post = Request::instance()->post();
        if(empty($this->uid)) {
            return returnjson(1100,'该用户已在其他设备登陆');
        }
        $user_model = new \app\wxapp\model\User;
        $user_model->where('id', $this->uid)->update(['token'=>'']);
        return returnjson(1000,'','已退出登录');
    }

    //生成邀请海报
    public function createqr() {

//        $goods_id = input('id');
//        $gname = $info['name'];
//        $imgpath = $info['images'];//商品头图
//        //return $imgpath;
//        include '../extend/phpqrcode/phpqrcode.php';
//        $Qr = new \phpqrcode\QRcode();
//        $value = 'http://shop.aixiaomage.com/index/goods/fgdetail/id/'.$goods_id.'.html'; //二维码内容
//        $errorCorrectionLevel = 'L';//容错级别
//        $matrixPointSize = 4;//生成图片大小
//        $Qr->png($value, 'qrcode.png', $errorCorrectionLevel, $matrixPointSize, 2);
//        list($width, $height, $type, $attr) = getimagesize($imgpath);
//        $dheight = $height * 1.53;
//        //1、创建画布
//        $im = imagecreatetruecolor(400,612);//新建一个真彩色图像，默认背景是黑色，返回图像标识符。另外还有一个函数 imagecreate 已经不推荐使用。
//        //2、绘制所需要的图像
//        $color =  imagecolorallocate($im,255,255,255);
//        imagefill($im,0,0,$color);  //填充颜色画布
//        $fcolor = imagecolorallocatealpha($im,0,0,0,0);//字体颜色
//        $pcolor = imagecolorallocate($im,255,0,0);//现价的颜色
//        $icolor = imagecolorallocatealpha($im,0,0,0,80);//活动形式颜色
//        $ncolor = imagecolorallocatealpha($im,0,0,0,100);//备注颜色
//        $fontfile = '../vendor/topthink/think-captcha/assets/zhttfs/2.ttf';//文本字体-微软雅黑
//        $gname  = $info['name'];//商品名字
//        $text = autowrap(13,0,$fontfile, $gname,320); // 自动换行处理
//        //若文件编码为 GB2312 请将下行的注释去掉
//        //$text = iconv("GB2312", "UTF-8", $text);
//        //imagettftext($im, 12, 0, 10, 30, $white, "simsun.ttc", $text);
//        $len    = mb_strlen($gname,'UTF8');//字符长度
//        $first  = mb_substr($gname,0,25);//第一行
//        $second = mb_substr($gname,26,$len);//第二行
//        imagettftext($im,13,0,20,50, $fcolor, $fontfile, $text);
//        $ext = strrchr($imgpath,'.');
//        if($ext == '.jpg' || $ext == '.jpeg') {
//            $img = @imagecreatefromjpeg($imgpath);
//        }elseif ($ext == '.png') {
//            $img = @imagecreatefrompng($imgpath);
//        }
//        $qrcode = @imagecreatefrompng('qrcode.png');
//        if($width > 400) {
//            imagecopyresampled($im,$img,0,100,0, 0,400,300*$height/$width,$width,$height);//商品图
//        }else if($height > 300) {
//            imagecopyresampled($im,$img,(400-400*$width/$height)/2,100,0, 0,400*$width/$height,300,$width,$height);//商品图
//        }else {
//            imagecopyresampled($im,$img,(400-$width)/2,100,0,0,$width,$height,$width,$height);//商品图
//        }
//        imagecopy ($im, $qrcode, 10, 450, 0, 0, 150, 150);//二维码
//        $nprice = '现价:￥'.$info1['now_price'];
//        $oprice = '原价：￥'.$info1['original_price'];
//        imageline($im,230,494,290,494,$icolor);
//        $note  = '长按识别图中二维码';
//        imagettftext($im,25,0,160,475,$pcolor,$fontfile,$nprice);//写入现价
//        imagettftext($im,13,0,160,500,$icolor,$fontfile,$oprice);//写入原价或活动
//        imagettftext($im,17,0,160,540,$ncolor,$fontfile,$note);//写入备注
//        imageantialias($im, true);
//        //3、输出图像
//        $ename = time() .rand(0000,9999);
//        header("content-type: image/jpeg");
//        imagejpeg($im,'./'.$ename.'.jpg',100);//输出到页面。如果有第二个参数[,$filename],则表示保存图像
//        //4、销毁图像，释放内存
//        imagedestroy($im);
//        //unlink();//删除二维码原图
//        $base = base64EncodeImage('./'.$ename.'.jpg');
//        unlink('./'.$ename.'.jpg');//删除二维码原图
//        return $base;
    }
}

